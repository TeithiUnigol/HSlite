#include "karakter.h"

class Boss:public Karakter{
public:
    Boss();
    void special(Karakter& k);
    ~Boss();
};
