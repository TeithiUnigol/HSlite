
#include <string>

class Kartya
{
protected:
    std::string nev;
    int manaKoltseg;
    char ikon;

public:
    Kartya(char* nev,int mana);
    Kartya(Kartya& k);
    bool kijatszas(int mana);
};