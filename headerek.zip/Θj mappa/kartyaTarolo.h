#include "kartya.h"

class KartyaTarolo{
    Kartya** tomb;
    size_t kapacitas;
    size_t meret;
public:
    KartyaTarolo(size_t kapacitas);
    void randomBeszur(Kartya* Kartya);
    Kartya* kihuz();
    size_t getMeret();
    Kartya* operator[](size_t index);
    void kiurites();
    ~KartyaTarolo();
};
