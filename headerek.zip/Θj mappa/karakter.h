#include "kartya.h"

class Karakter:public Kartya{
protected:
    double hp;
    double maxHp;
    bool aktiv;
public:
    Karakter();
    virtual void sebzodik(double sebzes);
    /// A karakterre meghatározott mértékű sebzést okoz.
    void regen(int hp);
    /// @return aktív-e az állapot.  
    bool aktiv();
    ///Újra aktívra állítja a karaktert. 
    void reaktiv();
    /// 
    void halal();
    ~Karakter();
};
