#include "kartya.h" 
#include "karakter.h"

class Varazslat:public Kartya{
    double sebzes;
    double gyogyitas;
    double vedelem;     
public:
    Varazslat();
    bool hatas(Karakter& karkater);
};