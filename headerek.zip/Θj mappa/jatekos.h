#include "kartya.h"
#include "boss.h"
#include "kartyaTarolo.h"

class Jatekos{
    int maxMana;
    int mana;
    Boss boss;
    KartyaTarolo kez;
    KartyaTarolo huzo;
    KartyaTarolo minionok;

public:
    Jatekos(Boss boss,KartyaTarolo huzoPakli,KartyaTarolo kezPakli,KartyaTarolo MinionPakli,int maxMana);
    void ujKor();
    ~Jatekos();
};
