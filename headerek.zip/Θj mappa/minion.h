#include "karakter.h"

class Minion:public Karakter{
private:
    double ero;
    double vedelem;
public:
    Minion();
    void sebzodik(double sebzes);
    //Egy meghatározott mértékben növelődik a minion támadása
    void vedelemValt(double d);
    ~Minion();
};
